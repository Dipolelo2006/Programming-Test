
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Student
 */
public class RunApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            try (Scanner sc = new Scanner(System.in)) {
                System.out.println("Enter the Console Type:");
                String ConsoleType= sc.nextLine();
                
                System.out.println("Enter the store for the console type:");
                String Store = sc.nextLine();
                
                System.out.println("Enter the total sales for" + ConsoleType + "for" + Store);
                int TotalSales = sc.nextInt();
                
                //Create the object
                YearlySalesReport report= new YearlySalesReport(ConsoleType,Store,TotalSales);
                
                //Print the report
                report.printSalesReport();
            }
    }

    }
    
