

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Student
 */
//=======1. Interface======
public interface IConsole {
    String getConsoleType();
    String getStore();
    int getTotalSales();
}

//======2. Abstract class======
abstract class Console implements IConsole{
    // Variables to store data
    private final String ConsoleType;
    private final String Store;
    private final int TotalSales;
    
    //Constructor
    public Console(String ConsoleType, String Store, int TotalSales){
        this.ConsoleType= ConsoleType;
        this.Store = Store;
        this.TotalSales= TotalSales;
    }
    //Getter methods
    @Override
    public String getConsoleType(){
        return ConsoleType;
    } 
    @Override
    public String getStore(){
        return Store;
    }
    @Override
    public int getTotalSales(){
        return TotalSales;
    }
}

//======3. Concrete subclass======
class YearlySalesReport extends Console{
    //Constructor- Calls the parent constructor
    public YearlySalesReport(String ConsoleType,String Store,int TotalSales){
        super(ConsoleType, Store, TotalSales);
    }
    //Method that prints the report
    public void printSalesReport(){
        System.out.println("\nCONSOLE SALES REPORT");
        System.out.println("******************************************");
        System.out.println("Console Type:"+ getConsoleType());
        System.out.println("Store:" + getStore());
        System.out.println("TotalSales:"+ getTotalSales());
        System.out.println("*****************************************");
}
}


