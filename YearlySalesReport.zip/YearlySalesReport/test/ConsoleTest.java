/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class ConsoleTest {
    
    public ConsoleTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getConsoleType method, of class Console.
     */
    @Test
    public void testGetConsoleType() {
        System.out.println("getConsoleType");
        Console instance = null;
        String expResult = "";
        String result = instance.getConsoleType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStore method, of class Console.
     */
    @Test
    public void testGetStore() {
        System.out.println("getStore");
        Console instance = null;
        String expResult = "";
        String result = instance.getStore();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalSales method, of class Console.
     */
    @Test
    public void testGetTotalSales() {
        System.out.println("getTotalSales");
        Console instance = null;
        int expResult = 0;
        int result = instance.getTotalSales();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class ConsoleImpl extends Console {

        public ConsoleImpl() {
            super("", "", 0);
        }
    
    }
}
