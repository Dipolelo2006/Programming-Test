/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package yearlysalesreport;

import java.util.Scanner;
/**
 *
 * @author Student
 */
public class YearlySalesReport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Single-Dimension for city names
        try (Scanner sc = new Scanner(System.in)) {
            //Single-Dimension for city names
            String[] cities= {"Cape Town","Port Elizabeth","Pretoria"};
            //Two-Dimensional array:rows=cities; columns= [PS5,XBOX,SWITCH]
            int[][] Console=new int[3][3];
            
            //======Input Section======
            for(int i=0;i<cities.length;i++){
                System.out.println("Enter the number of yearly sales for PS5 for"+" " + cities[i] +":");
                Console[i][0]=sc.nextInt();
                
                System.out.println("Enter the number of yearly sales for XBOX for"+" " + cities[i] + ":");
                Console[i][1]=sc.nextInt();
                
                System.out.println("Enter the number of yearly sales for SWITCH for"+" " + cities[i] + ":");
                Console[i][2]=sc.nextInt();
            }
            //======Detailed Report======
            System.out.println("\n------------------------------------------------");
            System.out.println("GAMING CONSOLE REPORT");
            System.out.println("-------------------------------------------------");
            System.out.printf("%-20s %-12s %-10s %-10s%n"," ", "PS5", "XBOX", "SWITCH");
            System.out.println("-------------------------------------------------");
            for(int i=0;i<cities.length;i++){
                System.out.printf("%-20s %-12d %-10d %-10d%n", cities[i], Console[i][0], Console[i][1], Console[i][2]);
            }
            //Total for each City
            System.out.println("\n-------------------------------------------------");
            System.out.println("CONSOLE SALES FOR EACH CITY");
            System.out.println("---------------------------------------------------");
            
            int[] cityTotal= new int[3];  //1D Array for totals
            int maxTotal=0;
            String cityWithMost=" ";
            
            for(int i=0;i<cities.length;i++){
                cityTotal[i]= Console[i][0] + Console[i][1] +Console[i][2];
                System.out.printf("%-20s %d%n", cities[i], cityTotal[i]);
                
                //Check the city with the most gaming consoles
                if(cityTotal[i]>maxTotal){
                    maxTotal=cityTotal[i];
                    cityWithMost=cities[i];
                }
            }
            //City with most gaming consoles
            System.out.println("\nCity with most sales:" + cityWithMost);
            System.out.println("----------------------------------------------------");
        }
    }
    
}
